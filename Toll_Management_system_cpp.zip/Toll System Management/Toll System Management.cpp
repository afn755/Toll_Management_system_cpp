#include <iostream>
#include <vector>
#include <ctime>
using namespace std;

enum VehicleType { Light_duty, Medium_duty, Heavy_duty };

class Vehicle {
private:
    VehicleType vehicleType;
    string vehicleNumber;

public:
    Vehicle() {}
    Vehicle(VehicleType vehicleType, string vehicleNumber) {
        this->vehicleType = vehicleType;
        this->vehicleNumber = vehicleNumber;
    }

    string getVehicleNumber() const {
        return vehicleNumber;
    }

    VehicleType getVehicleType() const {
        return vehicleType;
    }
};

struct TollInformation {
    string carNumber;
    char* date;
    int taxAmount;
    int ticketNumber;
};

class TollSystem {
private:
    vector<TollInformation> tollInfoList;

public:
    TollSystem() {}

    void addEntry(TollInformation tollInfo) {
        tollInfoList.push_back(tollInfo);
    }

    void searchEntry(string carNumber) {
        for (auto tollEntry : tollInfoList) {
            if (tollEntry.carNumber == carNumber) {
                cout << "\nToll Information for Vehicle Number: " << tollEntry.carNumber << endl;
                cout << "Ticket Number: " << tollEntry.ticketNumber;

                char choiceDate;
                cout << "\nDo you want to see the date of collected toll? (Y/N): ";
                cin >> choiceDate;
                if (toupper(choiceDate) == 'Y') {
                    cout << " Date: " << tollEntry.date;
                }

                cout << endl;
                return;
            }
        }
        cout << "Vehicle Number Not Found" << endl;
    }

    int generateRevenue() const {
        int amount = 0;
        for (auto tollTax : tollInfoList) {
            amount += tollTax.taxAmount;
        }
        return amount;
    }

    static int getTollTax(VehicleType vehicleType) {
        if (vehicleType == Light_duty)
            return 200;
        else if (vehicleType == Medium_duty)
            return 400;
        else if (vehicleType == Heavy_duty)
            return 700;
        else
            return 0;
    }
};

void printMenu() {
    cout << "\n*** Toll Management System ***" << endl;
    cout << "1. Add Vehicle" << endl;
    cout << "2. Display Total Tax Collected" << endl;
    cout << "3. Search for Vehicle Toll Information" << endl;
    cout << "4. Exit" << endl;
    cout << "Enter your choice: ";
}

int main() {
    TollSystem tollBox;
    int ticketNum = 1;

    while (true) {
        printMenu();
        int choice;
        cin >> choice;

        switch (choice) {
            case 1: {
                cout << "\nEnter Vehicle Number: ";
                string vehicleNumber;
                cin >> vehicleNumber;

                cout << "Choose Vehicle Type (1: Light_duty, 2: Medium_duty, 3: Heavy_duty): ";
                int typeChoice;
                cin >> typeChoice;

                VehicleType type;
                switch (typeChoice) {
                    case 1:
                        type = Light_duty;
                        break;
                    case 2:
                        type = Medium_duty;
                        break;
                    case 3:
                        type = Heavy_duty;
                        break;
                    default:
                        cout << "Invalid choice. Try again." << endl;
                        continue;
                }

                Vehicle newVehicle(type, vehicleNumber);

                time_t now = time(0);
                char* current_date = ctime(&now);

                TollInformation tollInfo = {.carNumber = newVehicle.getVehicleNumber(),
                                            .date = current_date,
                                            .taxAmount = TollSystem::getTollTax(newVehicle.getVehicleType()),
                                            .ticketNumber = ticketNum};

                tollBox.addEntry(tollInfo);
                ticketNum++;
                cout << "Vehicle added successfully!" << endl;
                break;
            }
            case 2: {
                cout << "\nTotal Tax Collected by Toll Box: " << tollBox.generateRevenue() << endl;
                break;
            }
            case 3: {
                cout << "\nEnter Vehicle Number to Search: ";
                string searchNumber;
                cin >> searchNumber;

                tollBox.searchEntry(searchNumber);
                break;
            }
            case 4: {
                cout << "\nExiting the Toll Management System. Goodbye!\n";
                return 0;
            }
            default:
                cout << "Invalid choice. Try again." << endl;
        }
    }

    return 0;
}
